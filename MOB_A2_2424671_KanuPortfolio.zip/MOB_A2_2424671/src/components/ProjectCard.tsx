import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { Project } from '../types';
import { Card, ui } from './UI';
import { colors } from '../theme';

export function ProjectCard({ project, onPress }: { project: Project; onPress: () => void }) {
  return <Pressable accessibilityRole="button" accessibilityLabel={`View details for ${project.title}`} onPress={onPress}>
    <Card>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 8, alignItems: 'flex-start' }}>
        <Text style={{ color: colors.text, fontWeight: '800', fontSize: 17, flex: 1 }}>{project.title}</Text>
        <Text style={{ color: colors.primary, fontSize: 20 }}>›</Text>
      </View>
      <Text style={ui.body}>{project.problem}</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
        {project.technologies.map(t => <View key={t} style={ui.pill}><Text style={ui.pillText}>{t}</Text></View>)}
      </View>
    </Card>
  </Pressable>;
}