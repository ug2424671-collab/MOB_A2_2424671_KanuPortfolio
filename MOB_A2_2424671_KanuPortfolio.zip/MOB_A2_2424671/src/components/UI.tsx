import React from 'react';
import { View, Text, Pressable, StyleSheet, ViewStyle } from 'react-native';
import { colors } from '../theme';

export function Page({ children }: { children: React.ReactNode }) {
  return <View style={styles.page}>{children}</View>;
}
export function Heading({ title, subtitle }: { title: string; subtitle?: string }) {
  return <View style={styles.heading}><Text accessibilityRole="header" style={styles.title}>{title}</Text>{subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}</View>;
}
export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[styles.card, style]}>{children}</View>;
}
export function PrimaryButton({ title, onPress, secondary = false }: { title: string; onPress: () => void; secondary?: boolean }) {
  return <Pressable accessibilityRole="button" onPress={onPress} style={({ pressed }) => [styles.button, secondary && styles.secondaryButton, pressed && { opacity: 0.78 }]}><Text style={[styles.buttonText, secondary && styles.secondaryButtonText]}>{title}</Text></Pressable>;
}
export function LabelValue({ label, value }: { label: string; value: string }) {
  return <View style={{ marginBottom: 12 }}><Text style={styles.label}>{label}</Text><Text style={styles.value}>{value}</Text></View>;
}
export const ui = StyleSheet.create({
  body: { color: colors.text, fontSize: 15, lineHeight: 23 },
  muted: { color: colors.muted, fontSize: 13, lineHeight: 19 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  pill: { backgroundColor: colors.paleBlue, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6, alignSelf: 'flex-start' },
  pillText: { color: colors.primaryDark, fontWeight: '700', fontSize: 12 }
});
const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: colors.background, padding: 18, gap: 16 },
  heading: { gap: 4, marginBottom: 2 },
  title: { fontSize: 27, fontWeight: '800', color: colors.text },
  subtitle: { fontSize: 14, lineHeight: 21, color: colors.muted },
  card: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 16, gap: 10 },
  button: { minHeight: 48, paddingHorizontal: 16, borderRadius: 12, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  buttonText: { color: '#FFFFFF', fontWeight: '700', fontSize: 15 },
  secondaryButton: { backgroundColor: colors.paleBlue, borderWidth: 1, borderColor: '#B7CCFF' },
  secondaryButtonText: { color: colors.primaryDark },
  label: { color: colors.muted, fontSize: 12, fontWeight: '700', marginBottom: 4 },
  value: { color: colors.text, fontSize: 15, lineHeight: 22 }
});