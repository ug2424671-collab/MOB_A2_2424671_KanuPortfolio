import React, { useEffect, useState } from 'react';
import { Alert, Image, ScrollView, Switch, Text, TextInput, View } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Page, Heading, Card, PrimaryButton, ui } from '../components/UI';
import { useProfile } from '../state/ProfileContext';
import { Profile } from '../types';
import { colors } from '../theme';

export function EditProfileScreen() {
  const { profile, updateProfile } = useProfile();
  const [draft, setDraft] = useState<Profile>(profile);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  useEffect(() => setDraft(profile), [profile]);
  const change = (key: keyof Profile, value: any) => setDraft(p => ({ ...p, [key]: value }));
  const validate = () => {
    const e: Record<string, string> = {};
    if (draft.headline.trim().length < 5) e.headline = 'Headline must be at least 5 characters.';
    if (draft.bio.trim().length < 20) e.bio = 'Biography must be at least 20 characters.';
    if (!draft.primarySkill.trim()) e.primarySkill = 'Enter your primary skill.';
    setErrors(e); return Object.keys(e).length === 0;
  };
  const pickImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) { Alert.alert('Photo access not granted', 'You can continue using the initials avatar, or enable photo access in device settings.'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: true, aspect: [1, 1], quality: 0.8 });
    if (result.canceled) { Alert.alert('Selection cancelled', 'Your existing profile image has not changed.'); return; }
    if (result.assets[0]?.uri) change('imageUri', result.assets[0].uri);
  };
  const takePhoto = async () => {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (!permission.granted) { Alert.alert('Camera access not granted', 'You can select a gallery image or keep the initials avatar.'); return; }
    const result = await ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [1, 1], quality: 0.8 });
    if (result.canceled) { Alert.alert('Capture cancelled', 'Your existing profile image has not changed.'); return; }
    if (result.assets[0]?.uri) change('imageUri', result.assets[0].uri);
  };
  const save = async () => {
    if (!validate()) { Alert.alert('Check the highlighted fields', 'Fix the validation messages before saving.'); return; }
    setSaving(true);
    try { await updateProfile(draft); Alert.alert('Profile saved', 'Your profile is stored on this device and should return after restart.'); }
    catch { Alert.alert('Could not save', 'Please try again. Your edits may not have been stored.'); }
    finally { setSaving(false); }
  };
  const field = (label: string, key: 'headline' | 'bio' | 'primarySkill', multiline = false) => <View style={{ gap: 6, marginBottom: 14 }}><Text style={{ fontWeight: '700', color: colors.text }}>{label}</Text><TextInput accessibilityLabel={label} value={draft[key]} onChangeText={v => change(key, v)} multiline={multiline} textAlignVertical={multiline ? 'top' : 'center'} style={{ borderWidth: 1, borderColor: errors[key] ? colors.danger : colors.border, backgroundColor: '#FFFFFF', borderRadius: 12, padding: 12, minHeight: multiline ? 112 : 48, color: colors.text, fontSize: 16 }} />{errors[key] ? <Text accessibilityLiveRegion="polite" style={{ color: colors.danger, fontSize: 13 }}>{errors[key]}</Text> : null}</View>;
  return <ScrollView><Page><Heading title="Edit profile" subtitle="Changes are saved locally on this device." />
    <Card><Text style={{ color: colors.text, fontWeight: '800', fontSize: 17 }}>Profile image</Text>{draft.imageUri ? <Image source={{ uri: draft.imageUri }} style={{ width: 100, height: 100, borderRadius: 50, alignSelf: 'center' }} /> : <Text style={ui.muted}>No photo selected. Your initials avatar appears on Home.</Text>}<PrimaryButton title="Choose from gallery" onPress={pickImage} /><PrimaryButton title="Take a photo" onPress={takePhoto} secondary /><PrimaryButton title="Remove photo" onPress={() => change('imageUri', null)} secondary /></Card>
    <Card>{field('Professional headline', 'headline')}{field('Short biography (20+ characters)', 'bio', true)}{field('Primary skill', 'primarySkill')}<View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><View style={{ flex: 1, gap: 3 }}><Text style={{ color: colors.text, fontWeight: '700' }}>Available for opportunities</Text><Text style={ui.muted}>{draft.available ? 'Currently available' : 'Not currently available'}</Text></View><Switch value={draft.available} onValueChange={v => change('available', v)} trackColor={{ true: colors.primary }} /></View></Card>
    <PrimaryButton title={saving ? 'Saving…' : 'Validate and save profile'} onPress={save} />
    <Text style={ui.muted}>Validation rules: headline at least 5 characters; biography at least 20 characters; primary skill cannot be blank.</Text>
  </Page></ScrollView>;
}