import React from 'react';
import { ScrollView } from 'react-native';
import { Page, Heading } from '../components/UI';
import { ProjectCard } from '../components/ProjectCard';
import { projects } from '../data/portfolio';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/types';

type Props = NativeStackScreenProps<RootStackParamList, 'Tabs'>;
export function ProjectsScreen({ navigation }: any) {
  return <ScrollView><Page><Heading title="Projects" subtitle="Coursework and practice projects. Review each entry and personalize your contribution." />
    {projects.map(project => <ProjectCard key={project.id} project={project} onPress={() => navigation.getParent()?.navigate('ProjectDetails', { projectId: project.id })} />)}
  </Page></ScrollView>;
}