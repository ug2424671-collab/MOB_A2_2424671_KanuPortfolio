import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Page, Heading, Card, ui } from '../components/UI';
import { projects } from '../data/portfolio';
import { RouteProp, useRoute } from '@react-navigation/native';
import { RootStackParamList } from '../navigation/types';
import { colors } from '../theme';

export function ProjectDetailsScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'ProjectDetails'>>();
  const project = projects.find(p => p.id === route.params.projectId);
  if (!project) return <Page><Heading title="Project not found" subtitle="Return to Projects and select an available item." /></Page>;
  return <ScrollView><Page><Heading title={project.title} subtitle="Project overview" />
    <Card><Text style={{ color: colors.text, fontWeight: '800', fontSize: 17 }}>Problem</Text><Text style={ui.body}>{project.problem}</Text></Card>
    <Card><Text style={{ color: colors.text, fontWeight: '800', fontSize: 17 }}>My contribution</Text><Text style={ui.body}>{project.contribution}</Text></Card>
    <Card><Text style={{ color: colors.text, fontWeight: '800', fontSize: 17 }}>Technologies</Text><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{project.technologies.map(t => <View key={t} style={ui.pill}><Text style={ui.pillText}>{t}</Text></View>)}</View></Card>
    <Card><Text style={{ color: colors.text, fontWeight: '800', fontSize: 17 }}>Status and honesty note</Text><Text style={ui.body}>{project.statusNote}</Text></Card>
  </Page></ScrollView>;
}