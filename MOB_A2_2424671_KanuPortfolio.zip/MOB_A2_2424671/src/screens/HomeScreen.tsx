import React from 'react';
import { ScrollView, Text, Image, View } from 'react-native';
import { Page, Heading, Card, PrimaryButton, ui } from '../components/UI';
import { useProfile } from '../state/ProfileContext';
import { colors } from '../theme';

export function HomeScreen({ navigation }: any) {
  const { profile } = useProfile();
  return <ScrollView contentContainerStyle={{ flexGrow: 1 }}><Page>
    <Heading title="My name is Kiir Kiir Deng kur." subtitle="A short introduction to my learning journey." />
    <Card>
      <View style={{ alignItems: 'center', gap: 12 }}>
        {profile.imageUri ? <Image source={{ uri: profile.imageUri }} style={{ width: 104, height: 104, borderRadius: 52 }} /> : <View accessibilityLabel="Student avatar" style={{ width: 104, height: 104, borderRadius: 52, backgroundColor: colors.paleBlue, alignItems: 'center', justifyContent: 'center' }}><Text style={{ fontSize: 40, color: colors.primary, fontWeight: '800' }}>K</Text></View>}
        <Text accessibilityRole="header" style={{ fontSize: 23, color: colors.text, fontWeight: '800', textAlign: 'center' }}>Kiir Kiir Deng kur</Text>
        <Text style={[ui.body, { textAlign: 'center', fontWeight: '700' }]}>{profile.headline}</Text>
        <Text style={[ui.body, { textAlign: 'center' }]}>{profile.bio}</Text>
        <View style={ui.pill}><Text style={ui.pillText}>MOB-A2-4671</Text></View>
      </View>
    </Card>
    <Card><Text style={{ color: colors.text, fontWeight: '800', fontSize: 18 }}>Current focus</Text><Text style={ui.body}>Building useful, accessible mobile experiences and strengthening my software development practice.</Text><PrimaryButton title="Explore my projects" onPress={() => navigation.navigate('Tabs', { screen: 'Projects' })} /></Card>
    <Text style={ui.muted}>Core portfolio information is available offline. Optional external links are not required.</Text>
  </Page></ScrollView>;
}