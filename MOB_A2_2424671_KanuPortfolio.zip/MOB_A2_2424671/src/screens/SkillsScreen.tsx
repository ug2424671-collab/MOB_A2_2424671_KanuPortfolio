import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Page, Heading, Card, ui } from '../components/UI';
import { skills, education } from '../data/portfolio';
import { colors } from '../theme';

export function SkillsScreen() {
  return <ScrollView><Page><Heading title="Skills & education" subtitle="A truthful snapshot of my current learning." />
    {skills.map((s, i) => <Card key={s.name}><View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}><View style={{ width: 36, height: 36, borderRadius: 12, backgroundColor: colors.paleBlue, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: colors.primary, fontWeight: '800' }}>{i + 1}</Text></View><View style={{ flex: 1, gap: 3 }}><Text style={{ color: colors.text, fontWeight: '800', fontSize: 16 }}>{s.name}</Text><Text style={ui.muted}>{s.level}</Text></View></View></Card>)}
    <Heading title="Education timeline" subtitle="Edit the details to match your official programme and dates." />
    {education.map(e => <Card key={e.title}><Text style={{ color: colors.primary, fontWeight: '800' }}>{e.period}</Text><Text style={{ color: colors.text, fontWeight: '800', fontSize: 17 }}>{e.title}</Text><Text style={ui.body}>{e.detail}</Text></Card>)}
  </Page></ScrollView>;
}