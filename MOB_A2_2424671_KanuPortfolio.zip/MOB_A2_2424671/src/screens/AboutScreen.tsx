import React from 'react';
import { Alert, ScrollView, Text } from 'react-native';
import { Page, Heading, Card, PrimaryButton, LabelValue, ui } from '../components/UI';
import { resetProfile } from '../storage/profileStorage';
import { useProfile } from '../state/ProfileContext';
import { colors } from '../theme';

export function AboutScreen() {
  const { updateProfile } = useProfile();
  const reset = () => Alert.alert('Reset profile?', 'This removes locally saved profile edits and restores the starter profile.', [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Reset', style: 'destructive', onPress: async () => { await resetProfile(); await updateProfile({ headline: 'Computer Science Student | Aspiring Mobile Developer', bio: 'I am a Computer Science student developing practical skills in mobile application development, Python and user-interface design.', primarySkill: 'React Native', available: true, imageUri: null }); Alert.alert('Reset complete', 'Starter profile restored.'); } }
  ]);
  return <ScrollView><Page><Heading title="About this app" subtitle="Release and identity information." />
    <Card><LabelValue label="Application" value="KanuPortfolio" /><LabelValue label="Student" value="Kiir Kiir Deng kur — verify the exact official spelling before submission." /><LabelValue label="Registration number" value="2424671" /><LabelValue label="Individual verification code" value="MOB-A2-4671" /><LabelValue label="Version" value="1.0.0 (preview scaffold)" /><LabelValue label="Android package" value="rw.ac.ines.ug2424671.kanuportfolio" /></Card>
    <Card><Text style={{ color: colors.text, fontWeight: '800', fontSize: 17 }}>Data use</Text><Text style={ui.body}>Editable portfolio fields and the selected image URI are stored locally on this device using AsyncStorage. This app does not ask for passwords or send profile data to a server. Removing the app may remove its local data.</Text></Card>
    <Card><Text style={{ color: colors.text, fontWeight: '800', fontSize: 17 }}>Offline use</Text><Text style={ui.body}>Core portfolio screens and locally saved profile data are designed to work offline. EAS cloud builds and external repository links require an internet connection.</Text></Card>
    <PrimaryButton title="Reset saved profile" onPress={reset} secondary />
    <Text style={ui.muted}>Before final release, replace any placeholder education/project wording and test on a real Android device.</Text>
  </Page></ScrollView>;
}