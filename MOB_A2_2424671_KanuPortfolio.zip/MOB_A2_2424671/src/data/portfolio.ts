import { Project } from '../types';

export const skills = [
  { name: 'React Native', level: 'Learning and practice' },
  { name: 'TypeScript', level: 'Learning and practice' },
  { name: 'Python', level: 'Coursework and practice' },
  { name: 'GitHub', level: 'Version-control practice' },
  { name: 'UI design', level: 'Wireframes and interface planning' }
];

export const education = [
  { period: 'Current', title: 'Computer Science studies', detail: 'INES Ruhengeri — update this with your exact programme and dates.' },
  { period: 'Ongoing', title: 'Mobile and AI coursework', detail: 'React Native, Expo, TypeScript and introductory AI concepts.' }
];

// These are coursework-based portfolio examples. Edit the contribution/status to match what you personally completed.
export const projects: Project[] = [
  {
    id: 'harvest-lab',
    title: 'Musanze Cooperative Harvest and Dispatch Decision Lab',
    problem: 'A fictional cooperative needs a clear way to inspect harvest data and support planning decisions.',
    contribution: 'Coursework concept: data preparation and exploration of yield prediction, classification, clustering and dispatch recommendations. Replace this with the exact tasks you completed.',
    technologies: ['Python', 'NumPy', 'Data analysis'],
    statusNote: 'Coursework concept; do not claim a finished production system unless you have built and tested it.'
  },
  {
    id: 'mobile-coursework',
    title: 'React Native Mobile Coursework',
    problem: 'A small mobile app needs clear screens, reliable input handling and understandable navigation.',
    contribution: 'Coursework practice with React Native/Expo, form controls, navigation concepts and interface design. Update with a specific app you actually built.',
    technologies: ['React Native', 'Expo', 'TypeScript'],
    statusNote: 'Learning portfolio entry; add screenshots and verified features after testing.'
  }
];