export const colors = {
  primary: '#155EEF',
  primaryDark: '#123B9A',
  background: '#F4F7FC',
  surface: '#FFFFFF',
  text: '#152238',
  muted: '#64748B',
  border: '#DCE4F0',
  success: '#15803D',
  danger: '#B42318',
  paleBlue: '#EAF1FF',
  paleRed: '#FEF3F2'
};