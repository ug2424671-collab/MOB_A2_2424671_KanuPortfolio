import AsyncStorage from '@react-native-async-storage/async-storage';
import { Profile } from '../types';

const PROFILE_KEY = '@kanuportfolio/profile/v1';

export const defaultProfile: Profile = {
  headline: 'Computer Science Student | Aspiring Mobile Developer',
  bio: 'I am a Computer Science student developing practical skills in mobile application development, Python and user-interface design.',
  primarySkill: 'React Native',
  available: true,
  imageUri: null
};

export async function loadProfile(): Promise<Profile> {
  try {
    const raw = await AsyncStorage.getItem(PROFILE_KEY);
    if (!raw) return defaultProfile;
    const parsed = JSON.parse(raw) as Partial<Profile>;
    return { ...defaultProfile, ...parsed };
  } catch {
    return defaultProfile;
  }
}

export async function saveProfile(profile: Profile): Promise<void> {
  await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
}

export async function resetProfile(): Promise<void> {
  await AsyncStorage.removeItem(PROFILE_KEY);
}