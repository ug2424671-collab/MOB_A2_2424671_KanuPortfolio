export type Profile = {
  headline: string;
  bio: string;
  primarySkill: string;
  available: boolean;
  imageUri: string | null;
};
export type Project = {
  id: string;
  title: string;
  problem: string;
  contribution: string;
  technologies: string[];
  statusNote: string;
};