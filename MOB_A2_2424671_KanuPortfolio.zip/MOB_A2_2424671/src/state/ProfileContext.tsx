import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { Profile } from '../types';
import { defaultProfile, loadProfile, saveProfile } from '../storage/profileStorage';

type ProfileContextValue = { profile: Profile; ready: boolean; updateProfile: (p: Profile) => Promise<void> };
const Context = createContext<ProfileContextValue | null>(null);
export function ProfileProvider({ children }: { children: React.ReactNode }) {
  const [profile, setProfile] = useState<Profile>(defaultProfile);
  const [ready, setReady] = useState(false);
  useEffect(() => { loadProfile().then(setProfile).finally(() => setReady(true)); }, []);
  const updateProfile = async (p: Profile) => { setProfile(p); await saveProfile(p); };
  const value = useMemo(() => ({ profile, ready, updateProfile }), [profile, ready]);
  return <Context.Provider value={value}>{children}</Context.Provider>;
}
export function useProfile() {
  const value = useContext(Context);
  if (!value) throw new Error('useProfile must be used inside ProfileProvider');
  return value;
}