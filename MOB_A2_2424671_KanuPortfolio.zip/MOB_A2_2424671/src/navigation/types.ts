export type RootStackParamList = {
  Tabs: undefined;
  ProjectDetails: { projectId: string };
};
export type TabParamList = {
  Home: undefined;
  Skills: undefined;
  Projects: undefined;
  EditProfile: undefined;
  About: undefined;
};