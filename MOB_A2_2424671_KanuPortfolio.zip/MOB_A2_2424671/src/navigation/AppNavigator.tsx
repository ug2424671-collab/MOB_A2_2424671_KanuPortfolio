import React from 'react';
import { ActivityIndicator, View } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { HomeScreen } from '../screens/HomeScreen';
import { SkillsScreen } from '../screens/SkillsScreen';
import { ProjectsScreen } from '../screens/ProjectsScreen';
import { ProjectDetailsScreen } from '../screens/ProjectDetailsScreen';
import { EditProfileScreen } from '../screens/EditProfileScreen';
import { AboutScreen } from '../screens/AboutScreen';
import { RootStackParamList, TabParamList } from './types';
import { colors } from '../theme';
import { useProfile } from '../state/ProfileContext';

const Tab = createBottomTabNavigator<TabParamList>();
const Stack = createNativeStackNavigator<RootStackParamList>();

function Tabs() {
  const icons: Record<keyof TabParamList, keyof typeof Ionicons.glyphMap> = {
    Home: 'home-outline', Skills: 'construct-outline', Projects: 'folder-outline',
    EditProfile: 'person-circle-outline', About: 'information-circle-outline'
  };
  return <Tab.Navigator screenOptions={({ route }) => ({
    headerShown: false, tabBarActiveTintColor: colors.primary, tabBarInactiveTintColor: colors.muted,
    tabBarLabelStyle: { fontSize: 10, fontWeight: '600' }, tabBarStyle: { minHeight: 62, paddingTop: 6, paddingBottom: 7 },
    tabBarIcon: ({ color, size }) => <Ionicons name={icons[route.name as keyof TabParamList]} size={size} color={color} />
  })}>
    <Tab.Screen name="Home" component={HomeScreen} />
    <Tab.Screen name="Skills" component={SkillsScreen} />
    <Tab.Screen name="Projects" component={ProjectsScreen} />
    <Tab.Screen name="EditProfile" component={EditProfileScreen} options={{ title: 'Edit' }} />
    <Tab.Screen name="About" component={AboutScreen} />
  </Tab.Navigator>;
}
export function AppNavigator() {
  const { ready } = useProfile();
  if (!ready) return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background }}><ActivityIndicator size="large" color={colors.primary} /></View>;
  return <Stack.Navigator><Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} /><Stack.Screen name="ProjectDetails" component={ProjectDetailsScreen} options={{ title: 'Project details', headerBackTitle: 'Back', headerTintColor: colors.primary }} /></Stack.Navigator>;
}