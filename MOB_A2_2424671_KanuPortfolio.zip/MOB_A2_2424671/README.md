My name is Kiir Kiir Deng kur.

# KanuPortfolio — SWE 3409 Individual Assignment 2

## Student identity
- Full name: Kiir Kiir Deng kur
- Registration number: 2424671
- Verification code: MOB-A2-4671
- App name: KanuPortfolio
- Android package: `rw.ac.ines.ug2424671.kanuportfolio`
- GitHub username: `kanukiir-afk`
- Intended repository name: `MOB_A2_2424671`
- Intended repository URL: `https://github.com/kanukiir-afk/MOB_A2_2424671` (create the repository and verify the URL before submission)

## Purpose
An offline-first student portfolio app built with React Native, Expo and TypeScript to introduce a student to a recruiter.

## Features in the source scaffold
- Home introduction with the required first sentence, profile/avatar, headline, biography and verification code
- Skills and education timeline
- Project list and separate project-detail screen
- Bottom-tab navigation and native-stack project details
- Controlled profile editor with field-level validation
- Camera/gallery selection, preview, replace and remove workflow
- AsyncStorage save/load/reset for low-risk profile data and the local image URI
- About screen with app and student details and data-use statement
- EAS preview profile configured to produce an Android APK

## Project contents
- `App.tsx`, `src/`: TypeScript app source, navigation, screens, reusable UI, data and local storage
- `assets/`: asset instructions; add a personally selected profile image if desired
- `docs/MOB_A2_2424671_UIUX.pdf`: six-page UI/UX design document
- `evidence/MOB_A2_2424671_TEST_LOG.pdf`: test log template; replace NOT TESTED with real results after testing
- `evidence/MOB_A2_2424671_DECLARATION.pdf`: declaration draft; review and sign only if accurate
- `evidence/AI_USE.md`: AI-use disclosure to review and update truthfully

## Open in VS Code on Ubuntu or Windows
Install Node.js LTS and Git, extract this ZIP, then open the `MOB_A2_2424671` folder in VS Code.

```bash
npm install
npx expo install --fix
npm run typecheck
npx expo start
```

The Expo development preview is useful for development, but it does **not** satisfy the standalone APK requirement.

## Build the standalone Android APK
Install the EAS CLI and sign in to your Expo account:

```bash
npm install -g eas-cli
eas login
eas build --platform android --profile preview
```

After EAS finishes, download the generated APK and test it on a physical Android device without Expo Go. The APK is not included in this source-only ZIP because a real EAS build and device verification have not yet been completed.

## GitHub submission
Create a personal repository named `MOB_A2_2424671` under `kanukiir-afk`, then push this project. Before submission:
1. Verify the repository URL works and is public or shared with the lecturer.
2. Commit the finished, tested files.
3. Create release tag `v1.0.0`.
4. Attach `MOB_A2_2424671.apk` and `MOB_A2_2424671_DEMO.mp4` to the release.
5. Put the actual final commit hash, release URL, APK URL, tested device model and Android version here and in the evidence.

## Personalization and honest evidence
The listed skills should reflect the student's genuine abilities. Review the sample project descriptions and edit each contribution statement to describe work actually completed. Do not claim tests, an APK build, a physical-device run, a GitHub release, or a video are complete until they have been performed. The test log and declaration are templates, not proof of passing results.

## Known limitations
- Source code and documentation are provided; APK build, physical-device tests, demo video and GitHub release remain to be completed.
- The UI/UX PDF describes the planned scaffold. Compare it with the final app and add final screenshots if the implementation differs.
