# GitHub setup — KanuPortfolio

GitHub username: `kanukiir-afk`
Repository name: `MOB_A2_2424671`
Expected URL after creation: `https://github.com/kanukiir-afk/MOB_A2_2424671`

The URL above is a planned URL, not confirmation that the repository already exists.

From the project folder, after creating the empty repository on GitHub:

```bash
git init
git add .
git commit -m "Build KanuPortfolio assignment scaffold"
git branch -M main
git remote add origin https://github.com/kanukiir-afk/MOB_A2_2424671.git
git push -u origin main
```

If `git init` has already been run, do not run it again. If a remote already exists, inspect it with `git remote -v` before changing it. Do not commit passwords, tokens, `node_modules`, caches, or private information.
