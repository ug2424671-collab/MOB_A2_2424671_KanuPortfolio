Optional: add a profile image you have permission to use. The app also supports choosing a local photo on the device.
