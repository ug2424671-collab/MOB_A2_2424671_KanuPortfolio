# AI Use Disclosure — draft to review

This project scaffold was prepared with AI assistance. AI assistance was used to help organize the React Native/Expo TypeScript project, draft starter components and navigation, suggest profile validation and AsyncStorage patterns, and prepare documentation templates.

The student must review, understand, test, and personalize every part of the project before submission. Project contribution statements must describe only work actually completed by the student. No test, APK build, GitHub push, release, or physical-device verification should be reported as complete until it has actually happened.

Student: Kiir Kiir Deng kur (confirm official spelling)
Registration number: 2424671
Verification code: MOB-A2-4671

Edit this disclosure if the actual use of AI differs from this description, and follow INES course policy.
